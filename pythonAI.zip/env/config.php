<?php

/*server configuration*/

/*server configuration*/
define('server', 'localhost');
define('user', 'root');
define('password', '');
define('database', 'task_ai');


// define('server', 'localhost');
// define('user', 'memehubc_task_ai');
// define('password', 'memehubc_task_ai');
// define('database', 'memehubc_task_ai');



//paypall callback
function paypal_callback($arr_body=[],$client_id="")
{
    //any additional paypal functions are done here
    $payment_id = $arr_body['id'];
    $payer_id = $arr_body['payer']['payer_info']['payer_id'];
    $payer_email=$cc[0] = $arr_body['payer']['payer_info']['email'];
    $amount = $arr_body['transactions'][0]['amount']['total'];
    $currency = 'usd';
    $payment_status = $arr_body['state'];

   
}


// email for contact us 
define('webmaster_email', 'lennoxlondow3@gmail.com');
