<?php
session_start();
require_once '../controlers/my_accountControler.php';
require_once '../blades/header.php';


?>


<div class="dashbard">
  <div class="side-nav" id="dashboard-side-nav">
    <?php include '../blades/side_nav.php';  ?>
  </div>

  <div class="main-nav">
    <h1 class="sz-h2 wt-black text-left non_ck text-center" <?php $element->is_editable(current_page_table, 'page_title_phrase', 'text'); ?>><?php echo $page_title_phrase; ?></h1>
    <div class="labels">

      <button class="label">
        <a href="<?php echo base_path . "purchase"; ?>">
          <p class="t" <?php $element->is_editable(current_page_table, 'page_title_phrase1', 'text'); ?>><?php echo $page_title_phrase1; ?></p>
          <span><i class="fa fa-dollar"></i></span> <i class="fa  fa-3x"><?php echo $balance;   ?></i>
        </a>
      </button>

      <button class="label">
        <a href="<?php echo base_path . "subscribe"; ?>">
          <p class="t" <?php $element->is_editable(current_page_table, 'page_title_phrase2', 'text'); ?>><?php echo $page_title_phrase2; ?></p>
          <span><i class="fa fa-bolt"></i></span> <i class="fa  fa-3x"><?php echo $tokens > 100000 ? "100000+" : $tokens;   ?></i>
        </a>
      </button>

      <button class="label">
        <a href="<?php echo base_path . "documents"; ?>">
          <p class="t" <?php $element->is_editable(current_page_table, 'page_title_phrase3', 'text'); ?>><?php echo $page_title_phrase3; ?></p>
          <span><i class="fa fa-file"></i></span> <i class="fa  fa-3x"><?php echo $my_documents > 1000 ? "1000+" : $my_documents;   ?></i>
        </a>
      </button>

      <button class="label">
        <a href="<?php echo base_path . "trash"; ?>">
          <p class="t" <?php $element->is_editable(current_page_table, 'page_title_phrase4', 'text'); ?>><?php echo $page_title_phrase4; ?></p>
          <span><i class="fa fa-trash"></i></span> <i class="fa  fa-3x"><?php echo $trash > 1000 ? "1000+" : $trash;   ?></i>
        </a>
      </button>

    </div>
  </div>

</div>

<?php
require_once '../blades/footer.php';
?>