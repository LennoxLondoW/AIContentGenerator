<?php
/*main operation file*/
require_once '../app/extensions/app.element.php';
require_once '../app/extensions/app.validation.php';
require_once '../app.extensions/app.front.extension.php';
//loging in check
if(!isset($_SESSION['email']))
{
	//do something
	//$_SESSION['current_page'] = $_SERVER['REQUEST_URI'];
	// header('location:'.base_path."/sign_in");
	// die();
}
else
{
	// do something
	// if(!isset($_SESSION['admin_edits'])){
	// 	header('location:' . $page );
	// }
}

$element = new Element();
$element->activeTable = "lentec_pricing";
$element->comparisons = [];
$element->joiners = [''];  
$element->order = " BY id DESC ";
$element->cols = "section_id, section_title"; 
$element->limit = 2000;
$element->offset = 0;
/*get_data*/
$data = $element ->GetElementData();
