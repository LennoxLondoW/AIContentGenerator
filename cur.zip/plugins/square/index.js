// here is a link to load square
const square_url = 'https://sandbox.web.squarecdn.com/v1/square.js'

//function to load js files dynamically

async function editCard () {
  // Initialize the Square Payments object with your application ID and the ID of the seller location where the payment is taken.
  const payments = Square.payments(
    'sandbox-sq0idb-tflPhZgfNfvuXCEmrld_1Q',
    'L1XDDR0GPJ4PZ'
  )
  // Get a new Card object
  // This creates a new Card instance with all of the behaviors and properties needed to take a card payment.
  const card = await payments.card()
  // Attach the Card instance to a DOM element
  // Attach the Card instance to an empty DOM element on your page. The payment card form renders into the empty element, turning it into a secure payment card form.
  //take svg
  let cont = document.getElementById('card-container')
  let svg = cont.innerHTML
  cont.innerHTML = ''
  await card.attach('#card-container')
  // Get the payment token
  // Get the payment form token from the Card instance when the buyer completes the form by calling the tokenize method.
  async function eventHandler (event) {
    event.preventDefault()
    const statusContainer = document.getElementById('payment-status-container')

    try {
      const result = await card.tokenize()
      //   console.log(result)

      if (result.status === 'OK') {
        // console.log(`Payment token is ${result.token}`)
        statusContainer.innerHTML = svg
        //here we use ajax to send data to the backend
        let data = {
          response: JSON.stringify(result),
          add_cards: true
        }

        $.ajax({
          url: $('#base_path').val() + 'plugins/square/index.php',
          type: 'POST',
          timeout: 30000,
          data: data,
          success: function (site_response) {
            // console.log(site_response)
            eval(site_response)
          },
          error: function (a, b, c) {
            alert('Something is not right')
          }
        })
      } else {
        statusContainer.innerHTML = 'Payment Failed'
      }
    } catch (e) {
      //   console.error(e)
      statusContainer.innerHTML = 'Payment Failed'
    }
  }

  const cardButton = document.getElementById('card-button')
  cardButton.addEventListener('click', eventHandler)
}

function squareFunctions () {
  if (document.getElementById('card-container') !== null) {
    editCard()
  }
}

loadJS(
  square_url,
  (callback = 'squareFunctions();'),
  (attributes = { type: 'text/javascript', async: false })
)
