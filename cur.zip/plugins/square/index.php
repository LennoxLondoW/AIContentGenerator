<?php
session_start();
/*main operation file*/
$__path__ = "../../";
require_once '../../app/extensions/app.validation.php';
$validation = new Validation();


if (isset($_POST['add_cards'])) {
    // check loging in 
    if (!isset($_SESSION['email'])) {
        die("statusContainer.innerHTML = 'Error! Please log in to proceed!';");
    }

    // validation object 
    $validation = new Validation();
    // table to store cards 
    $validation->activeTable = "lentec_user_cards";
    //check forgery
    if (!$validation->same_origin()) {
        die("statusContainer.innerHTML = 'Error! This request has been rejected!';");
    }
    // decode response 
    $array = json_decode($_POST['response'], true);
    // check for response status 
    if ($array['status'] !== 'OK') {
        die("statusContainer.innerHTML = 'Error! This request has been rejectedd!';");
    }
    // data to be inserted into square table 
    $array['details']['card']['expMonth'] = $array['details']['card']['expMonth'] < 10 ? "0" . $array['details']['card']['expMonth'] : $array['details']['card']['expMonth'];
    $validation->insertData = [
        [
            "account_email" => $_SESSION['email'],
            "token" => $array["token"],
            "brand" => $array['details']['card']['brand'],
            "expMonth" => $array['details']['card']['expMonth'],
            "expYear" => $array['details']['card']['expYear'],
            "expDate" => $array['details']['card']['expYear'] . "/" . $array['details']['card']['expMonth'],
            "last4" => $array['details']['card']['last4'],
            "method" => $array['details']['method'],
            "postalCode" => $array['details']['billing']['postalCode']
        ]
    ];

    //lets try to store this data// update the following columns if there is a duplicate
    // $save = $validation->saveData([
    //     "token",
    //     "brand",
    //     "expMonth",
    //     "expYear",
    //     "expDate",
    //     "last4",
    //     "method",
    //     "postalCode",
    // ]);


    $save = $validation->saveData(false);



    if ($save === "success") {
        //we alert user that there card has been added successfully
        // we issue out free tokens to be used
        //fetch free user tokens to be awarded
        $free_tokens = new App();
        $free_tokens->activeTable = "lentec_subscribe";
        $free_tokens->comparisons = [["section_id", " = ", 'free_tokens']];
        $free_tokens->joiners = [''];
        $free_tokens->order = " BY id DESC ";
        $free_tokens->cols = "*";
        $free_tokens->limit = 1;
        $free_tokens->offset = 0;
        $token_data = $free_tokens->getData()[0]['section_title'];

        //we issue out free tokens
        die("statusContainer.innerHTML = 'Success! Your've been given free 1000 tokens subscription that expires in 10 days!';");
    } elseif (strstr(strtolower($save), "lentec_user_cards' doesn't exist") !== false) {
        // table doesn't exist// we import migration module to create this table
        require_once '../../app/extensions/app.migration.php';
        $migration = new Migration();
        /* adjust tables*/
        $migration->tables = [
            "lentec_user_cards" => [
                "id int(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY",
                "account_email varchar(255) NOT NULL UNIQUE KEY",
                "token varchar(255) NOT NULL UNIQUE KEY",
                "brand varchar(255) NOT NULL",
                "expMonth varchar(255) NOT NULL",
                "expYear varchar(255) NOT NULL",
                "expDate varchar(255) NOT NULL",
                "last4 varchar(255) NOT NULL",
                "method varchar(255) NOT NULL",
                "postalCode varchar(255) NOT NULL"
            ]
        ];
        /*migrate the tables */
        $status = $migration->migrate();
        if ($status === "success") {
            //re insert the card data into the table
            // $save = $validation->saveData([
            //     "token",
            //     "brand",
            //     "expMonth",
            //     "expYear",
            //     "expDate",
            //     "last4",
            //     "method",
            //     "postalCode",
            // ]);


            $save = $validation->saveData(false);

            if ($status === "success") {
                // success state 
                // we issue out free tokens to be used
                //fetch free user tokens to be awarded
                $free_tokens = new App();
                $free_tokens->activeTable = "lentec_subscribe";
                $free_tokens->comparisons = [["section_id", " = ", 'free_tokens']];
                $free_tokens->joiners = [''];
                $free_tokens->order = " BY id DESC ";
                $free_tokens->cols = "*";
                $free_tokens->limit = 1;
                $free_tokens->offset = 0;
                $token_data = $free_tokens->getData()[0]['section_title'];


                //we issue out free tokens
                die("statusContainer.innerHTML = 'Success! Your've been given free 1000 tokens subscription that expires in 10 days!';");
            } elseif (strstr(strtolower($save), "duplicate entry") !== false) {
                die("statusContainer.innerHTML = 'Error! This card is already registered with us!';");
            } else {
                // error state 
                die("statusContainer.innerHTML = 'Error! Something is not right, please try again!';");
            }
        }
        // table creation failed 
        die("statusContainer.innerHTML = 'Error! Something is not right, please try again!';");
    } elseif (strstr(strtolower($save), "duplicate entry") !== false) {
        die("statusContainer.innerHTML = 'Error! This card is already registered with us!';");
    } else {
        // just another unexpected error 
        die("statusContainer.innerHTML = 'Error! Something is not right, please try again!';");
    }
}
