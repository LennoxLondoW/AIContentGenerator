<?php
/*main operation file*/
require_once '../app/extensions/app.element.php';
// $_SESSION['admin_edits'] = 'set';
//loging in


if (isset($_GET['logout'])) {
	session_unset();
	session_destroy();
	header('location:' . base_path . "home");
	die();
}

$element = new Element();
//fetch this page data
$element->activeTable = "lentec_navbar";
$element->comparisons = [];
$element->joiners = [''];
$element->order = " BY id DESC ";
$element->cols = "section_id, section_title";
$element->limit = 1000;
$element->offset = 0;


/*get_data*/
$data = $element->GetElementData();
